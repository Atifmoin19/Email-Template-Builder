import React from 'react';
import {
  VStack,
  HStack,
  Box,
  Text,
  Icon,
  useColorModeValue,
  Heading,
  Button,
} from '@chakra-ui/react';
import {
  Layout,
  Type,
  Image as ImageIcon,
  Square,
  Minus,
  Columns,
  CreditCard,
  PanelTop,
  PanelBottom,
  ChevronLeft,
} from 'lucide-react';
import { useDraggable } from '@dnd-kit/core';
import { EmailNodeType } from './types';

interface SidebarItemProps {
  type: EmailNodeType;
  label: string;
  icon: any;
}

const SidebarItem: React.FC<SidebarItemProps> = ({ type, label, icon }) => {
  const { attributes, listeners, setNodeRef, transform, isDragging } = useDraggable({
    id: `sidebar-${type}`,
    data: {
      type,
      isNew: true,
    },
  });

  const bgColor = useColorModeValue('white', 'gray.800');
  const borderColor = useColorModeValue('gray.100', 'whiteAlpha.100');
  const hoverBg = useColorModeValue('gray.50', 'whiteAlpha.50');

  const style = undefined;

  return (
    <HStack
      ref={setNodeRef}
      style={style}
      {...listeners}
      {...attributes}
      w="full"
      p={3}
      bg={bgColor}
      borderWidth="1px"
      borderColor={borderColor}
      rounded="xl"
      cursor="grab"
      transition="all 0.2s"
      _hover={{ bg: hoverBg, transform: 'translateY(-2px)', shadow: 'sm' }}
      _active={{ cursor: 'grabbing', opacity: 0.5 }}
      opacity={isDragging ? 0.5 : 1}
      spacing={3}
    >
      <Box p={2} bg="primary.50" rounded="lg" color="primary.500">
        <Icon as={icon} size={18} />
      </Box>
      <Text fontSize="sm" fontWeight="700" letterSpacing="0.5px">
        {label}
      </Text>
    </HStack>
  );
};

interface EmailSidebarProps {
  onNavigate?: (id: string) => void;
}

const EmailSidebar: React.FC<EmailSidebarProps> = ({ onNavigate }) => {
  const borderColor = useColorModeValue('gray.200', 'gray.700');

  const components = [
    { type: 'section' as const, label: 'Section', icon: Layout },
    { type: 'column' as const, label: 'Column', icon: Columns },
    { type: 'text' as const, label: 'Text Block', icon: Type },
    { type: 'image' as const, label: 'Image', icon: ImageIcon },
    { type: 'button' as const, label: 'Button', icon: CreditCard },
    { type: 'divider' as const, label: 'Divider', icon: Minus },
    { type: 'spacer' as const, label: 'Spacer', icon: Square },
    { type: 'header' as const, label: 'Header', icon: PanelTop },
    { type: 'footer' as const, label: 'Footer', icon: PanelBottom },
  ];

  return (
    <VStack h="full" spacing={0} align="stretch">
      <Box p={4} borderBottom="1px" borderColor={borderColor}>
        <Button
           leftIcon={<Icon as={ChevronLeft} size={16} />}
           variant="ghost"
           colorScheme="primary"
           size="md"
           fontWeight="800"
           fontSize="sm"
           mb={4}
           onClick={() => onNavigate && onNavigate('Home')}
           _hover={{ transform: "translateX(-4px)" }}
           transition="0.2s"
           w="full"
           justifyContent="flex-start"
        >
            EXIT BUILDER
        </Button>
        <Heading size="xs" fontWeight="900" letterSpacing="widest" color="gray.400">
          COMPONENTS
        </Heading>
      </Box>
      <VStack flex={1} overflowY="auto" p={4} spacing={3} align="stretch">
        <Text fontSize="xs" fontWeight="800" color="gray.500" mb={1}>
          DRAG & DROP
        </Text>
        {components.map((comp) => (
          <SidebarItem key={comp.type} {...comp} />
        ))}
      </VStack>
    </VStack>
  );
};

export default EmailSidebar;
