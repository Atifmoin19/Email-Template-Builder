import { EmailNode } from '../types';

export interface CompatibilityWarning {
  id: string;
  type: 'warning' | 'error';
  message: string;
}

export const validateCompatibility = (nodes: EmailNode[]): CompatibilityWarning[] => {
  const warnings: CompatibilityWarning[] = [];

  const traverse = (node: EmailNode) => {
    // Check for images without alt text
    if (node.type === 'image' && !node.props.alt) {
      warnings.push({
        id: node.id,
        type: 'warning',
        message: 'Image is missing alt text. This is bad for accessibility and spam filters.'
      });
    }

    // Check for large images (simulated check)
    if (node.type === 'image' && node.props.width && parseInt(node.props.width) > 600) {
      warnings.push({
        id: node.id,
        type: 'warning',
        message: 'Image width exceeds 600px. This may cause horizontal scrolling in some clients.'
      });
    }

    // Check for background images (Outlook pitfall)
    if (node.props.backgroundImage) {
      warnings.push({
        id: node.id,
        type: 'error',
        message: 'Background images are not supported in many versions of Outlook. Use solid colors instead.'
      });
    }

    if (node.children) {
      node.children.forEach(traverse);
    }
  };

  nodes.forEach(traverse);
  return warnings;
};
