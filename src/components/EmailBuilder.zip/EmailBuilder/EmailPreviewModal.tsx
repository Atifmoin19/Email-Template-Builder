import React, { useState, useEffect } from "react";
import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalCloseButton,
  Tabs,
  TabList,
  Tab,
  TabPanels,
  TabPanel,
  Box,
  Center,
  Icon,
  Text,
  HStack,
  ModalFooter, // Added for potential future use, as it's in the provided snippet
  Button, // Added for potential future use, as it's in the provided snippet
  IconButton, // Added for potential future use, as it's in the provided snippet
  VStack, // Added for potential future use, as it's in the provided snippet
  useColorModeValue, // Added for potential future use, as it's in the provided snippet
} from "@chakra-ui/react";
import {
  Monitor,
  Smartphone,
  Tablet,
  Download,
  Copy,
  Check,
  AlertCircle,
  Eye,
  Code,
  ChevronRight,
  AlertTriangle,
} from "lucide-react"; // Added Download, Copy, Check
import { EmailNode, EmailProject } from "./types";
import { generateEmailHtml } from "./utils/emailRenderer"; // New import
import {
  validateCompatibility,
  CompatibilityWarning,
} from "./utils/emailCompatibility";

interface EmailPreviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  project: EmailProject;
}

const EmailPreviewModal: React.FC<EmailPreviewModalProps> = ({
  isOpen,
  onClose,
  project,
}) => {
  const [viewMode, setViewMode] = useState<"desktop" | "tablet" | "mobile">(
    "desktop",
  );
  const [hasCopied, setHasCopied] = useState(false); // New state from snippet

  const html = generateEmailHtml(project); // Use generateEmailHtml
  const warnings = validateCompatibility(project.nodes);

  // New functions from snippet
  const handleCopy = () => {
    navigator.clipboard.writeText(html);
    setHasCopied(true);
    setTimeout(() => setHasCopied(false), 2000);
  };

  const handleDownload = () => {
    const blob = new Blob([html], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "email-template.html";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const viewportWidth = {
    desktop: "600px",
    tablet: "450px",
    mobile: "320px",
  };

  const borderColor = useColorModeValue("gray.200", "gray.700");

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      size="full"
      scrollBehavior="inside"
    >
      <ModalOverlay backdropFilter="blur(10px)" bg="blackAlpha.300" />
      <ModalContent bg="gray.50" _dark={{ bg: "gray.900" }}>
        <ModalHeader borderBottomWidth="1px" p={4}>
          <HStack spacing={8} justify="center">
            <Text fontSize="sm" fontWeight="900" letterSpacing="widest">
              PREVIEW MODE
            </Text>
            <Tabs
              variant="soft-rounded"
              colorScheme="primary"
              index={["desktop", "tablet", "mobile"].indexOf(viewMode)}
              onChange={(i) =>
                setViewMode(["desktop", "tablet", "mobile"][i] as any)
              }
            >
              <TabList
                bg="white"
                _dark={{ bg: "whiteAlpha.100" }}
                p={1}
                rounded="xl"
              >
                <Tab px={6} py={2} fontSize="xs" fontWeight="800">
                  <Icon as={Monitor} mr={2} size={14} /> DESKTOP
                </Tab>
                <Tab px={6} py={2} fontSize="xs" fontWeight="800">
                  <Icon as={Tablet} mr={2} size={14} /> TABLET
                </Tab>
                <Tab px={6} py={2} fontSize="xs" fontWeight="800">
                  <Icon as={Smartphone} mr={2} size={14} /> MOBILE
                </Tab>
              </TabList>
            </Tabs>
          </HStack>
        </ModalHeader>
        <ModalCloseButton mt={2} />
        <ModalBody p={0} display="flex" h="full" overflow="hidden">
          <Box
            w="300px"
            borderRight="1px"
            borderColor={borderColor}
            bg="white"
            overflowY="auto"
          >
            <VStack p={4} align="stretch" spacing={4}>
              <Text
                fontSize="xs"
                fontWeight="900"
                letterSpacing="widest"
                color="gray.500"
              >
                COMPATIBILITY CHECK
              </Text>
              {warnings.length === 0 ? (
                <HStack
                  p={3}
                  bg="green.50"
                  rounded="md"
                  color="green.700"
                  spacing={3}
                >
                  <Check size={16} />
                  <Text fontSize="xs" fontWeight="700">
                    All good for production!
                  </Text>
                </HStack>
              ) : (
                warnings.map((w, idx) => (
                  <Box
                    key={idx}
                    p={3}
                    bg={w.type === "error" ? "red.50" : "yellow.50"}
                    rounded="md"
                    borderLeft="4px solid"
                    borderColor={w.type === "error" ? "red.400" : "yellow.400"}
                  >
                    <HStack mb={1}>
                      <Icon
                        as={w.type === "error" ? AlertCircle : AlertTriangle}
                        size={14}
                        color={w.type === "error" ? "red.500" : "yellow.600"}
                      />
                      <Text
                        fontSize="10px"
                        fontWeight="900"
                        color={w.type === "error" ? "red.700" : "yellow.800"}
                      >
                        {w.type.toUpperCase()}
                      </Text>
                    </HStack>
                    <Text fontSize="xs" color="gray.700">
                      {w.message}
                    </Text>
                  </Box>
                ))
              )}
            </VStack>
          </Box>
          <Box
            flex={1}
            bg={useColorModeValue("gray.50", "gray.800")}
            display="flex"
            flexDir="column"
            h="full"
          >
            <Tabs
              flex={1}
              display="flex"
              flexDir="column"
              p={0}
              variant="soft-rounded"
              colorScheme="primary"
              size="sm"
            >
              <TabList
                px={8}
                pt={4}
                bg="white"
                borderBottom="1px"
                borderColor={borderColor}
              >
                <HStack spacing={4}>
                  <Tab _selected={{ bg: "primary.50", color: "primary.600" }}>
                    <Icon as={Monitor} size={14} mr={2} /> Desktop
                  </Tab>
                  <Tab _selected={{ bg: "primary.50", color: "primary.600" }}>
                    <Icon as={Tablet} size={14} mr={2} /> Tablet
                  </Tab>
                  <Tab _selected={{ bg: "primary.50", color: "primary.600" }}>
                    <Icon as={Smartphone} size={14} mr={2} /> Mobile
                  </Tab>
                </HStack>
              </TabList>

              <TabPanels flex={1} overflowY="auto" p={8}>
                {/* Desktop View */}
                <TabPanel p={0} h="full" display="flex" flexDirection="column">
                  <VStack flex={1} py={12} px={4} spacing={0} overflowY="auto">
                    <Box
                      w="700px"
                      bg={"#fff"}
                      minH="500px"
                      shadow="2xl"
                      rounded="md"
                      display="flex"
                      flexDirection="column"
                      overflow="hidden"
                    >
                      <Box
                        h="30px"
                        bg="gray.100"
                        borderBottom="1px"
                        borderColor="gray.200"
                        px={3}
                        display="flex"
                        alignItems="center"
                        flexShrink={0}
                      >
                        <HStack spacing={1.5}>
                          <Box w="8px" h="8px" rounded="full" bg="red.400" />
                          <Box w="8px" h="8px" rounded="full" bg="yellow.400" />
                          <Box w="8px" h="8px" rounded="full" bg="green.400" />
                        </HStack>
                      </Box>
                      <Box w="full" overflow="auto">
                        <iframe
                          srcDoc={html}
                          style={{
                            width: "100%",
                            height: "100%",
                            minHeight: "400px",
                            border: "none",
                          }}
                          title="Desktop Preview"
                        />
                      </Box>
                    </Box>
                  </VStack>
                </TabPanel>

                {/* Tablet View */}
                <TabPanel p={0} h="full" display="flex" flexDirection="column">
                  <VStack flex={1} py={12} px={4} spacing={0} overflowY="auto">
                    <Box
                      w="450px"
                      // h="75vh"
                      minH="600px"
                      bg="white"
                      shadow="2xl"
                      rounded="3xl"
                      border="12px solid"
                      borderColor="gray.800"
                      display="flex"
                      flexDirection="column"
                      overflow="hidden"
                    >
                      <Box flex={1} w="full" overflow="auto">
                        <iframe
                          srcDoc={html}
                          style={{
                            width: "100%",
                            height: "100%",
                            minHeight: "600px",
                            border: "none",
                          }}
                          title="Tablet Preview"
                        />
                      </Box>
                    </Box>
                  </VStack>
                </TabPanel>

                {/* Mobile View */}
                <TabPanel p={0} h="full" display="flex" flexDirection="column">
                  <VStack flex={1} py={12} px={4} spacing={0} overflowY="auto">
                    <Box
                      w="320px"
                      // h="75vh"
                      minH="600px"
                      bg="white"
                      shadow="2xl"
                      rounded="3xl"
                      border="12px solid"
                      borderColor="gray.800"
                      display="flex"
                      flexDirection="column"
                      overflow="hidden"
                    >
                      <Box flex={1} w="full" overflow="auto">
                        <iframe
                          srcDoc={html}
                          style={{
                            width: "100%",
                            height: "100%",
                            minHeight: "600px",
                            border: "none",
                          }}
                          title="Mobile Preview"
                        />
                      </Box>
                    </Box>
                  </VStack>
                </TabPanel>
              </TabPanels>
            </Tabs>
          </Box>
        </ModalBody>

        <ModalFooter borderTop="1px" borderColor={borderColor}>
          <HStack spacing={3}>
            <Button
              variant="ghost"
              leftIcon={<Icon as={hasCopied ? Check : Copy} size={16} />}
              onClick={handleCopy}
              fontWeight="800"
              fontSize="xs"
              color={hasCopied ? "green.500" : "inherit"}
            >
              {hasCopied ? "COPIED!" : "COPY CODE"}
            </Button>
            <Button
              colorScheme="primary"
              leftIcon={<Icon as={Download} size={16} />}
              onClick={handleDownload}
              fontWeight="800"
              fontSize="xs"
              rounded="lg"
            >
              DOWNLOAD .HTML
            </Button>
          </HStack>
        </ModalFooter>
      </ModalContent>
    </Modal>
  );
};

export default EmailPreviewModal;
