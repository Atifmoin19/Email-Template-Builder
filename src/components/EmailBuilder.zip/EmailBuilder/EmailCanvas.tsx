import React from 'react';
import {
  Box,
  VStack,
  Center,
  Text,
  useColorModeValue,
  Button,
  HStack,
  Icon,
} from '@chakra-ui/react';
import { Eye, MousePointer2 } from 'lucide-react';
import { useDroppable } from '@dnd-kit/core';
import {
  SortableContext,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import { useDragState } from './context/DragStateContext';
import { EmailNode } from './types';
import EmailNodeWrapper from './components/EmailNodeWrapper';
import Section from './components/Section';
import TextComponent from './components/Text';
import ImageComponent from './components/Image';
import ButtonComponent from './components/Button';
import DividerComponent from './components/Divider';
import SpacerComponent from './components/Spacer';
import Header from './components/Header';
import Footer from './components/Footer';
import Column from './components/Column';

interface EmailCanvasProps {
  nodes: EmailNode[];
  selectedNodeId: string | null;
  onSelect: (id: string | null) => void;
  onDelete: (id: string) => void;
  onPreview: () => void;
}


const NodeRenderer: React.FC<{
  node: EmailNode;
  selectedNodeId: string | null;
  onSelect: (id: string) => void;
  onDelete: (id: string) => void;
}> = ({ node, selectedNodeId, onSelect, onDelete }) => {
  const isSelected = selectedNodeId === node.id;
  
  const renderComponent = () => {
    const children = node.children?.map(child => (
      <NodeRenderer 
        key={child.id} 
        node={child} 
        selectedNodeId={selectedNodeId}
        onSelect={onSelect}
        onDelete={onDelete}
      />
    ));

    switch (node.type) {
      case 'section':
        return <Section node={node}>{children}</Section>;
      case 'column':
        return <Column node={node}>{children}</Column>;
      case 'header':
        return <Header node={node}>{children}</Header>;
      case 'footer':
        return <Footer node={node}>{children}</Footer>;
      case 'text':
        return <TextComponent node={node} />;
      case 'image':
        return <ImageComponent node={node} />;
      case 'button':
        return <ButtonComponent node={node} />;
      case 'divider':
        return <DividerComponent node={node} />;
      case 'spacer':
        return <SpacerComponent node={node} />;
      default:
        return null;
    }
  };

  return (
    <EmailNodeWrapper
      id={node.id}
      type={node.type}
      isSelected={isSelected}
      onSelect={onSelect}
      onDelete={onDelete}
      flex={node.type === 'column' ? (node.props.flex || 1) : undefined}
      width={node.type === 'column' ? (node.props.width || '100%') : 'full'}
    >
      {renderComponent()}
    </EmailNodeWrapper>
  );
};

const EmailCanvas: React.FC<EmailCanvasProps> = ({
  nodes,
  selectedNodeId,
  onSelect,
  onDelete,
  onPreview,
}) => {
  const canvasBg = useColorModeValue('white', 'gray.900');
  const borderColor = useColorModeValue('gray.200', 'gray.700');

  const { setNodeRef, isOver } = useDroppable({
    id: 'canvas-root',
  });

  const { dragState } = useDragState();
  
  // Highlight canvas if hovering over the root box OR any of the root-level nodes
  const isCanvasTargeted = isOver || (dragState.overId && nodes.some(n => n.id === dragState.overId));

  return (
    <VStack spacing={6} w="full" align="center">
      <HStack w="full" justify="space-between" mb={4}>
        <HStack spacing={2} color="gray.500">
          <Icon as={MousePointer2} size={14} />
          <Text fontSize="xs" fontWeight="800" letterSpacing="widest">
            CANVAS WORKSPACE (A4)
          </Text>
        </HStack>
        <Button
          size="sm"
          variant="outline"
          leftIcon={<Icon as={Eye} size={14} />}
          onClick={onPreview}
          fontWeight="800"
          fontSize="xs"
          rounded="lg"
        >
          PREVIEW
        </Button>
      </HStack>

      <Box
        ref={setNodeRef}
        w="600px" // Standard email width
        minH="842px" // Approx A4 height at 72dpi
        bg={isCanvasTargeted ? 'primary.50' : canvasBg}
        boxShadow="xl"
        borderWidth="2px"
        borderColor={isCanvasTargeted ? 'primary.500' : borderColor}
        position="relative"
        transition="all 0.2s"
        onClick={() => onSelect(null)}
      >
        {nodes.length === 0 ? (
          <Center h="842px" flexDir="column">
            <VStack spacing={4} opacity={0.5}>
              <Box p={4} border="2px dashed" borderColor="gray.300" rounded="2xl">
                <Icon as={MousePointer2} size={32} color="gray.400" />
              </Box>
              <Text fontWeight="800" color="gray.500" fontSize="sm">
                DRAG COMPONENTS HERE
              </Text>
            </VStack>
          </Center>
        ) : (
          <SortableContext
            items={nodes.map((n) => n.id)}
            strategy={verticalListSortingStrategy}
          >
            <VStack spacing={0} align="stretch">
              {nodes.map((node) => (
                <NodeRenderer
                  key={node.id}
                  node={node}
                  selectedNodeId={selectedNodeId}
                  onSelect={onSelect}
                  onDelete={onDelete}
                />
              ))}
            </VStack>
          </SortableContext>
        )}
      </Box>
    </VStack>
  );
};

export default EmailCanvas;
