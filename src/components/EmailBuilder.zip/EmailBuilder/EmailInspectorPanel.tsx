import React from 'react';
import {
  VStack,
  Box,
  Text,
  Heading,
  useColorModeValue,
  HStack,
  IconButton,
  Button,
  Icon,
  Divider,
  Center,
  FormControl,
  FormLabel,
  Input,
  Select,
  NumberInput,
  NumberInputField,
  NumberInputStepper,
  NumberIncrementStepper,
  NumberDecrementStepper,
  Accordion,
  AccordionItem,
  AccordionButton,
  AccordionPanel,
  AccordionIcon,
} from '@chakra-ui/react';
import { Undo2, Redo2, Download, Settings2, Trash2, AlignLeft, AlignCenter, AlignRight } from 'lucide-react';
import { EmailNode, EmailSettings } from './types';
import { findNodeById, updateNodeInTree } from './utils/astHelpers';

interface EmailInspectorPanelProps {
  nodes: EmailNode[];
  setNodes: (nodes: EmailNode[]) => void;
  settings: EmailSettings;
  onUpdateSettings: (settings: Partial<EmailSettings>) => void;
  selectedNodeId: string | null;
  undo: () => void;
  redo: () => void;
  canUndo: boolean;
  canRedo: boolean;
  onDelete: (id: string) => void;
  onDownload: () => void;
}

const EmailInspectorPanel: React.FC<EmailInspectorPanelProps> = ({
  nodes,
  setNodes,
  settings,
  onUpdateSettings,
  selectedNodeId,
  undo,
  redo,
  canUndo,
  canRedo,
  onDelete,
  onDownload,
}) => {
  const bgColor = useColorModeValue('white', 'gray.900');
  const borderColor = useColorModeValue('gray.200', 'gray.700');

  const selectedNode = selectedNodeId ? findNodeById(nodes, selectedNodeId) : null;

  const updateNodeProps = (props: Record<string, any>) => {
    if (!selectedNodeId) return;
    const newNodes = updateNodeInTree(nodes, selectedNodeId, (node) => ({
      ...node,
      props: { ...node.props, ...props },
    }));
    setNodes(newNodes);
  };
  const renderTextSettings = () => (
    <VStack spacing={4} align="stretch">
      <FormControl>
        <FormLabel fontSize="xs" fontWeight="800" color="gray.500">CONTENT</FormLabel>
        <Input 
          size="sm" 
          value={selectedNode?.props.content || ''} 
          onChange={(e) => updateNodeProps({ content: e.target.value })}
          placeholder="Enter text..."
          rounded="md"
        />
      </FormControl>
      <FormControl>
        <FormLabel fontSize="xs" fontWeight="800" color="gray.500">COLOR</FormLabel>
        <Input 
          size="sm" 
          type="color"
          value={selectedNode?.props.color || '#000000'} 
          onChange={(e) => updateNodeProps({ color: e.target.value })}
          rounded="md"
        />
      </FormControl>
      <FormControl>
        <FormLabel fontSize="xs" fontWeight="800" color="gray.500">FONT SIZE</FormLabel>
        <Select 
          size="sm" 
          value={selectedNode?.props.fontSize || '16px'}
          onChange={(e) => updateNodeProps({ fontSize: e.target.value })}
          rounded="md"
        >
          {['12px', '14px', '16px', '18px', '20px', '24px', '32px'].map(size => (
            <option key={size} value={size}>{size}</option>
          ))}
        </Select>
      </FormControl>
      <FormControl>
        <FormLabel fontSize="xs" fontWeight="800" color="gray.500">TEXT PRESET</FormLabel>
        <Select 
          size="sm" 
          rounded="md" 
          value={selectedNode?.props.variant || 'paragraph'}
          onChange={(e) => {
            const variant = e.target.value;
            let updates: any = { variant };
            if (variant === 'heading') {
              updates = { ...updates, fontSize: '32px', fontWeight: '800' };
            } else if (variant === 'subheader') {
              updates = { ...updates, fontSize: '24px', fontWeight: '700' };
            } else {
              updates = { ...updates, fontSize: '16px', fontWeight: 'normal' };
            }
            updateNodeProps(updates);
          }}
        >
          <option value="heading">Heading</option>
          <option value="subheader">Subheader</option>
          <option value="paragraph">Paragraph</option>
        </Select>
      </FormControl>

      <HStack>
        <FormControl>
          <FormLabel fontSize="xs" fontWeight="800" color="gray.500">FONT SIZE</FormLabel>
          <Input 
            size="sm" 
            value={selectedNode?.props.fontSize ?? ''} 
            onChange={(e) => updateNodeProps({ fontSize: e.target.value })}
            placeholder="e.g. 16px"
            rounded="md"
          />
        </FormControl>
        <FormControl>
          <FormLabel fontSize="xs" fontWeight="800" color="gray.500">TEXT COLOR</FormLabel>
          <Input 
            size="sm" 
            type="color"
            value={selectedNode?.props.color || '#000000'} 
            onChange={(e) => updateNodeProps({ color: e.target.value })}
            rounded="md"
          />
        </FormControl>
      </HStack>

      <FormControl>
        <FormLabel fontSize="xs" fontWeight="800" color="gray.500">FONT WEIGHT</FormLabel>
        <Select 
          size="sm" 
          rounded="md" 
          value={selectedNode?.props.fontWeight ?? 'normal'}
          onChange={(e) => updateNodeProps({ fontWeight: e.target.value })}
        >
          <option value="normal">Normal</option>
          <option value="500">Medium</option>
          <option value="600">Semi-Bold</option>
          <option value="700">Bold</option>
          <option value="800">Extra-Bold</option>
        </Select>
      </FormControl>

      <FormControl>
        <FormLabel fontSize="xs" fontWeight="800" color="gray.500">ALIGNMENT</FormLabel>
        <HStack spacing={2}>
          <IconButton aria-label="Align Left" icon={<AlignLeft size={14} />} size="sm" onClick={() => updateNodeProps({ textAlign: 'left' })} isActive={selectedNode?.props.textAlign === 'left'} />
          <IconButton aria-label="Align Center" icon={<AlignCenter size={14} />} size="sm" onClick={() => updateNodeProps({ textAlign: 'center' })} isActive={selectedNode?.props.textAlign === 'center'} />
          <IconButton aria-label="Align Right" icon={<AlignRight size={14} />} size="sm" onClick={() => updateNodeProps({ textAlign: 'right' })} isActive={selectedNode?.props.textAlign === 'right'} />
        </HStack>
      </FormControl>
    </VStack>
  );

  const renderImageSettings = () => (
    <VStack spacing={4} align="stretch">
      <FormControl>
        <FormLabel fontSize="xs" fontWeight="800" color="gray.500">IMAGE URL</FormLabel>
        <Input 
          size="sm" 
          value={selectedNode?.props.src || ''} 
          onChange={(e) => updateNodeProps({ src: e.target.value })}
          placeholder="https://example.com/image.png"
          rounded="md"
        />
      </FormControl>
      <FormControl>
        <FormLabel fontSize="xs" fontWeight="800" color="gray.500">ALT TEXT</FormLabel>
        <Input 
          size="sm" 
          value={selectedNode?.props.alt || ''} 
          onChange={(e) => updateNodeProps({ alt: e.target.value })}
          placeholder="Image description"
          rounded="md"
        />
      </FormControl>
      <HStack>
        <FormControl>
          <FormLabel fontSize="xs" fontWeight="800" color="gray.500">WIDTH (%)</FormLabel>
          <Input 
            size="sm" 
            value={selectedNode?.props.width ?? ''} 
            onChange={(e) => updateNodeProps({ width: e.target.value })}
            rounded="md"
          />
        </FormControl>
        <FormControl>
          <FormLabel fontSize="xs" fontWeight="800" color="gray.500">HEIGHT (PX)</FormLabel>
          <Input 
            size="sm" 
            value={selectedNode?.props.height ?? ''} 
            onChange={(e) => updateNodeProps({ height: e.target.value })}
            placeholder="Auto"
            rounded="md"
          />
        </FormControl>
      </HStack>
      <FormControl>
        <FormLabel fontSize="xs" fontWeight="800" color="gray.500">OBJECT FIT</FormLabel>
        <Select 
          size="sm" 
          rounded="md" 
          value={selectedNode?.props.objectFit ?? 'contain'}
          onChange={(e) => updateNodeProps({ objectFit: e.target.value })}
        >
          <option value="contain">Contain</option>
          <option value="cover">Cover</option>
          <option value="fill">Fill</option>
          <option value="scale-down">Scale Down</option>
          <option value="none">None</option>
        </Select>
      </FormControl>
    </VStack>
  );

  const renderButtonSettings = () => (
    <VStack spacing={4} align="stretch">
      <FormControl>
        <FormLabel fontSize="xs" fontWeight="800" color="gray.500">BUTTON TEXT</FormLabel>
        <Input 
          size="sm" 
          value={selectedNode?.props.content ?? ''} 
          onChange={(e) => updateNodeProps({ content: e.target.value })}
          rounded="md"
        />
      </FormControl>
      <FormControl>
        <FormLabel fontSize="xs" fontWeight="800" color="gray.500">LINK URL</FormLabel>
        <Input 
          size="sm" 
          value={selectedNode?.props.href || ''} 
          onChange={(e) => updateNodeProps({ href: e.target.value })}
          placeholder="https://example.com"
          rounded="md"
        />
      </FormControl>
      <HStack>
        <FormControl>
          <FormLabel fontSize="xs" fontWeight="800" color="gray.500">BG COLOR</FormLabel>
          <Input 
            size="sm" 
            type="color"
            value={selectedNode?.props.backgroundColor || '#3182ce'} 
            onChange={(e) => updateNodeProps({ backgroundColor: e.target.value })}
            rounded="md"
          />
        </FormControl>
        <FormControl>
          <FormLabel fontSize="xs" fontWeight="800" color="gray.500">TEXT COLOR</FormLabel>
          <Input 
            size="sm" 
            type="color"
            value={selectedNode?.props.color || '#ffffff'} 
            onChange={(e) => updateNodeProps({ color: e.target.value })}
            rounded="md"
          />
        </FormControl>
      </HStack>
      <FormControl>
        <FormLabel fontSize="xs" fontWeight="800" color="gray.500">ALIGNMENT</FormLabel>
        <Select 
          size="sm" 
          rounded="md" 
          value={selectedNode?.props.align ?? 'center'}
          onChange={(e) => updateNodeProps({ align: e.target.value })}
        >
          <option value="left">Left</option>
          <option value="center">Center</option>
          <option value="right">Right</option>
        </Select>
      </FormControl>
    </VStack>
  );

  const renderColumnSettings = () => (
    <VStack spacing={4} align="stretch">
      <FormControl>
        <FormLabel fontSize="xs" fontWeight="800" color="gray.500">COLUMN SPAN</FormLabel>
        <NumberInput 
          size="sm" 
          min={1} 
          max={4}
          value={selectedNode?.props.colSpan || 1}
          onChange={(val) => updateNodeProps({ colSpan: parseInt(val) })}
        >
          <NumberInputField rounded="md" />
          <NumberInputStepper>
            <NumberIncrementStepper />
            <NumberDecrementStepper />
          </NumberInputStepper>
        </NumberInput>
      </FormControl>
      <FormControl>
        <FormLabel fontSize="xs" fontWeight="800" color="gray.500">WIDTH (%)</FormLabel>
        <Input 
          size="sm" 
          value={selectedNode?.props.width || '100%'} 
          onChange={(e) => updateNodeProps({ width: e.target.value })}
          placeholder="e.g. 50%"
          rounded="md"
        />
      </FormControl>
    </VStack>
  );

  const renderGlobalSettings = () => (
    <VStack spacing={6} align="stretch">
      <Heading size="xs" textTransform="uppercase" letterSpacing="widest" color="primary.500">
        GLOBAL PAGE SETTINGS
      </Heading>
      
      <FormControl>
        <FormLabel fontSize="xs" fontWeight="800" color="gray.500">PAGE BACKGROUND</FormLabel>
        <Input 
          size="sm" 
          type="color"
          value={settings.pageBackgroundColor} 
          onChange={(e) => onUpdateSettings({ pageBackgroundColor: e.target.value })}
          rounded="md"
        />
      </FormControl>

      <FormControl>
        <FormLabel fontSize="xs" fontWeight="800" color="gray.500">CONTENT BACKGROUND</FormLabel>
        <Input 
          size="sm" 
          type="color"
          value={settings.contentBackgroundColor} 
          onChange={(e) => onUpdateSettings({ contentBackgroundColor: e.target.value })}
          rounded="md"
        />
      </FormControl>

      <FormControl>
        <FormLabel fontSize="xs" fontWeight="800" color="gray.500">FONT FAMILY</FormLabel>
        <Select 
          size="sm" 
          rounded="md" 
          value={settings.fontFamily}
          onChange={(e) => onUpdateSettings({ fontFamily: e.target.value })}
        >
          <option value="Helvetica, Arial, sans-serif">Helvetica/Arial</option>
          <option value="'Times New Roman', serif">Times New Roman</option>
          <option value="Georgia, serif">Georgia</option>
          <option value="Verdana, sans-serif">Verdana</option>
          <option value="'Courier New', monospace">Courier New</option>
        </Select>
      </FormControl>

      <FormControl>
        <FormLabel fontSize="xs" fontWeight="800" color="gray.500">MAX CONTENT WIDTH (PX)</FormLabel>
        <Input 
          size="sm" 
          value={settings.maxWidth} 
          onChange={(e) => onUpdateSettings({ maxWidth: e.target.value })}
          rounded="md"
        />
      </FormControl>

      <FormControl>
        <FormLabel fontSize="xs" fontWeight="800" color="gray.500">INNER PADDING</FormLabel>
        <Input 
          size="sm" 
          value={settings.globalPadding} 
          onChange={(e) => onUpdateSettings({ globalPadding: e.target.value })}
          rounded="md"
        />
      </FormControl>
    </VStack>
  );

  const renderSectionSettings = () => (
    <VStack spacing={4} align="stretch">
      <FormControl>
        <FormLabel fontSize="xs" fontWeight="800" color="gray.500">GRID COLUMNS</FormLabel>
        <Select 
          size="sm" 
          rounded="md" 
          value={selectedNode?.props.gridColumns || 1}
          onChange={(e) => updateNodeProps({ gridColumns: parseInt(e.target.value) })}
        >
          <option value={1}>1 Column</option>
          <option value={2}>2 Columns</option>
          <option value={3}>3 Columns</option>
          <option value={4}>4 Columns</option>
        </Select>
      </FormControl>
      <FormControl>
        <FormLabel fontSize="xs" fontWeight="800" color="gray.500">LAYOUT TYPE</FormLabel>
        <Select 
          size="sm" 
          rounded="md" 
          value={selectedNode?.props.layout || 'full-width'}
          onChange={(e) => updateNodeProps({ layout: e.target.value })}
        >
          <option value="full-width">Full Width</option>
          <option value="boxed">Boxed (600px)</option>
        </Select>
      </FormControl>
    </VStack>
  );

  const renderHeaderFooterSettings = () => (
    <VStack spacing={4} align="stretch">
      <FormControl>
        <FormLabel fontSize="xs" fontWeight="800" color="gray.500">GRID COLUMNS</FormLabel>
        <Select 
          size="sm" 
          rounded="md" 
          value={selectedNode?.props.gridColumns || 1}
          onChange={(e) => updateNodeProps({ gridColumns: parseInt(e.target.value) })}
        >
          <option value={1}>1 Column</option>
          <option value={2}>2 Columns</option>
          <option value={3}>3 Columns</option>
          <option value={4}>4 Columns</option>
        </Select>
      </FormControl>
    </VStack>
  );

  const renderCommonSettings = () => (
    <Accordion allowMultiple defaultIndex={[0]}>
      <AccordionItem border="none">
        <AccordionButton px={0} _hover={{ bg: 'transparent' }}>
          <Box flex="1" textAlign="left">
            <Text fontSize="xs" fontWeight="900" letterSpacing="widest" color="primary.500">STYLE & LAYOUT</Text>
          </Box>
          <AccordionIcon />
        </AccordionButton>
        <AccordionPanel pb={4} px={0}>
          <VStack spacing={4} align="stretch">
            <FormControl>
              <FormLabel fontSize="xs" fontWeight="800" color="gray.500">BACKGROUND COLOR</FormLabel>
              <Input 
                size="sm" 
                type="color"
                value={selectedNode?.props.backgroundColor ?? ''} 
                onChange={(e) => updateNodeProps({ backgroundColor: e.target.value })}
                rounded="md"
              />
            </FormControl>
            <FormControl>
              <FormLabel fontSize="xs" fontWeight="800" color="gray.500">PADDING (PX)</FormLabel>
              <Input 
                size="sm" 
                value={selectedNode?.props.padding ?? ''} 
                onChange={(e) => updateNodeProps({ padding: e.target.value })}
                rounded="md"
              />
            </FormControl>
          </VStack>
        </AccordionPanel>
      </AccordionItem>
    </Accordion>
  );

  return (
    <VStack h="full" bg={bgColor} spacing={0} align="stretch">
      {/* Header Actions */}
      <Box p={4} borderBottom="1px" borderColor={borderColor}>
        <HStack justify="space-between" spacing={2}>
          <HStack spacing={1}>
            <IconButton
              aria-label="Undo"
              icon={<Undo2 size={16} />}
              size="sm"
              variant="ghost"
              onClick={undo}
              isDisabled={!canUndo}
            />
            <IconButton
              aria-label="Redo"
              icon={<Redo2 size={16} />}
              size="sm"
              variant="ghost"
              onClick={redo}
              isDisabled={!canRedo}
            />
          </HStack>
          <Button
            leftIcon={<Download size={16} />}
            colorScheme="primary"
            size="sm"
            onClick={onDownload}
            fontWeight="800"
            fontSize="xs"
            rounded="lg"
            px={4}
          >
            DOWNLOAD
          </Button>
        </HStack>
      </Box>

      {/* Inspector Content */}
      <Box flex={1} overflowY="auto" p={4}>
        {!selectedNode ? (
          renderGlobalSettings()
        ) : (
          <VStack spacing={6} align="stretch">
            <HStack justify="space-between">
              <VStack align="left" spacing={0}>
                <Heading size="xs" textTransform="uppercase" letterSpacing="widest" color="primary.500">
                  {selectedNode.type}
                </Heading>
                <Text fontSize="10px" color="gray.400" fontWeight="700">ID: {selectedNode.id}</Text>
              </VStack>
              <IconButton
                aria-label="Delete"
                icon={<Trash2 size={14} />}
                size="xs"
                variant="ghost"
                color="red.400"
                _hover={{ bg: 'red.50' }}
                onClick={() => onDelete(selectedNode.id)}
              />
            </HStack>

            <Divider borderColor={borderColor} />

            {selectedNode.type === 'text' && renderTextSettings()}
            {selectedNode.type === 'image' && renderImageSettings()}
            {selectedNode.type === 'button' && renderButtonSettings()}
            {selectedNode.type === 'section' && renderSectionSettings()}
            {selectedNode.type === 'column' && renderColumnSettings()}
            {(selectedNode.type === 'header' || selectedNode.type === 'footer') && renderHeaderFooterSettings()}
            {renderCommonSettings()}
          </VStack>
        )}
      </Box>
    </VStack>
  );
};

export default EmailInspectorPanel;
